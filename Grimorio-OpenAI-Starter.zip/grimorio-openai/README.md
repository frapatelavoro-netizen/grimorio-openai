# Grimorio OpenAI — pacchetto di pubblicazione

Questa è una ricostruzione autonoma e mobile-first di Grimorio. Il progetto originale resta intatto. Include UI fantasy, selettore D&D 5e 2014/2024, compendio iniziale, assistente OpenAI lato server, personaggi, dadi, preferiti, backup/import JSON e manifest PWA.

## Pubblicazione su Render

Il repository include `render.yaml` per impostare automaticamente il servizio Node. La chiave OpenAI **non** è inclusa nel codice e va inserita soltanto nella dashboard Render.

1. Estrai lo ZIP sul computer.
2. Accedi a GitHub e crea un repository nuovo e privato chiamato `grimorio-openai` (non modificare né sovrascrivere il progetto originale).
3. Carica nel repository il contenuto della cartella estratta, compresi `render.yaml`, `package.json`, `server/`, `src/` e `public/`. Non caricare `.env` né `node_modules`.
4. Accedi a Render, scegli **New → Blueprint**, collega il repository GitHub appena creato e conferma la creazione del servizio. Render legge `render.yaml`; build: `npm install && npm run build`, start: `npm start`.
5. Nel servizio Render apri **Environment** e aggiungi `OPENAI_API_KEY` con la chiave creata in OpenAI Platform. Facoltativamente aggiungi `OPENAI_MODEL` (predefinito `gpt-4.1-mini`) e `AI_RATE_LIMIT_PER_MINUTE` (predefinito 8). Non inserire la chiave nel frontend, in GitHub o in chat.
6. Salva e avvia un nuovo deploy. Quando lo stato è **Live**, apri l'URL `https://...onrender.com` e prova l'Oracolo. `/api/health` mostra se la chiave è configurata, ma non mostra la chiave.
7. Su iPhone apri l'URL in Safari → Condividi → **Aggiungi alla schermata Home**.

## Sicurezza e costi

- La chiave API è letta esclusivamente dal backend (`OPENAI_API_KEY`), mai da una variabile `VITE_*`.
- Sono attivi header di sicurezza e un rate limit in memoria (8 richieste/minuto per IP, configurabile). Il limite in memoria è adatto a un singolo servizio/istanza; prima di scalare a più istanze va sostituito con un limiter condiviso. Non è un sistema di autenticazione: chiunque trovi l'URL può usare le funzioni pubbliche entro il limite.
- Imposta un budget/limiti di spesa in OpenAI Platform e controlla l'uso. La fatturazione OpenAI API è separata dal piano ChatGPT e dall'eventuale costo dell'hosting.
- Non committare `.env`, chiavi o segreti. Se una chiave viene esposta, revocala e creane una nuova.

## Test locale

Richiede Node.js 20 o successivo. Esegui `npm install`, copia `.env.example` in `.env`, inserisci `OPENAI_API_KEY` solo nel file locale e avvia `npm run dev`. Per la build: `npm run build`; per servire il build: `npm start`.

## Limiti attuali

- Il compendio è uno scheletro iniziale, non un database completo di tutte le regole.
- L'assistente non usa ancora RAG o un archivio verificato di fonti ufficiali/SRD: dichiara i limiti e non deve inventare citazioni.
- Personaggi e preferiti sono salvati nel browser locale; non c'è sincronizzazione cloud. Usa l'esportazione JSON per il backup.
- Prima di un rilascio pubblico più ampio servono test, informativa privacy, verifica delle licenze dei contenuti D&D e, se vuoi account privati, autenticazione.

## Installazione su iPhone

Dopo la pubblicazione HTTPS, apri il sito in Safari su iPhone → Condividi → Aggiungi alla schermata Home. Questa PWA non implementa ancora una cache offline completa.
