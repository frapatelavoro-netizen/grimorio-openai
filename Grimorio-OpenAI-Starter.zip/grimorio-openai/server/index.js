import express from 'express';
import OpenAI from 'openai';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const PORT = Number(process.env.PORT || 8787);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
// Basic hardening for a small single-instance deployment. For multiple instances,
// move rate limiting to a shared store (e.g. Redis) before scaling horizontally.
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (process.env.NODE_ENV === 'production') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  next();
});
app.use(express.json({ limit: '32kb', strict: true }));

const rateWindowMs = 60_000;
const rateMax = Number(process.env.AI_RATE_LIMIT_PER_MINUTE || 8);
const requestCounts = new Map();
app.use('/api/assistant', (req, res, next) => {
  const now = Date.now();
  const key = req.ip || req.socket.remoteAddress || 'unknown';
  const entry = requestCounts.get(key);
  if (!entry || now - entry.startedAt >= rateWindowMs) {
    requestCounts.set(key, { startedAt: now, count: 1 });
    return next();
  }
  entry.count += 1;
  if (entry.count > rateMax) {
    res.setHeader('Retry-After', String(Math.ceil((rateWindowMs - (now - entry.startedAt)) / 1000)));
    return res.status(429).json({ error: 'Hai raggiunto il limite temporaneo di richieste. Attendi un minuto e riprova.' });
  }
  next();
});
// Periodically remove expired entries so the in-memory limiter stays bounded.
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of requestCounts) {
    if (now - entry.startedAt >= rateWindowMs) requestCounts.delete(key);
  }
}, rateWindowMs).unref();

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.OPENAI_API_KEY), model: process.env.OPENAI_MODEL || 'gpt-4.1-mini' });
});

app.post('/api/assistant', async (req, res) => {
  const { question, edition, history = [] } = req.body || {};
  if (req.headers['content-type'] && !req.is('application/json')) {
    return res.status(415).json({ error: 'Invia la richiesta in formato JSON.' });
  }
  if (typeof question !== 'string' || !question.trim() || question.length > 5000) {
    return res.status(400).json({ error: 'Inserisci una domanda (massimo 5000 caratteri).' });
  }
  if (!['2014', '2024'].includes(edition)) {
    return res.status(400).json({ error: 'Edizione non valida: scegli 2014 oppure 2024.' });
  }
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: 'API OpenAI non configurata. Aggiungi OPENAI_API_KEY nelle variabili segrete del server.' });
  }
  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const safeHistory = Array.isArray(history) ? history.slice(-8).filter(m =>
      m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string'
    ).map(m => ({ role: m.role, content: m.content.slice(0, 3000) })) : [];
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
      instructions: `Sei Grimorio, assistente in italiano per Dungeons & Dragons. EDIZIONE ATTIVA: D&D 5e ${edition}. Non mescolare mai le regole 2014 e 2024: rispondi solo per l'edizione attiva. Se una regola non è verificabile con le informazioni disponibili, dichiaralo esplicitamente e non inventare citazioni, pagine o fonti. Distingui chiaramente regole ufficiali, interpretazioni e suggerimenti. Non dichiarare di aver consultato libri o siti se non hai accesso a tali fonti nella richiesta. Chiedi chiarimenti se la domanda è ambigua. Non riprodurre lunghi passaggi di manuali protetti da copyright; riassumi con parole tue. Specifica sempre l'edizione in apertura della risposta e indica quando serve consultare la fonte ufficiale.`,
      input: [...safeHistory, { role: 'user', content: question.trim() }]
    });
    res.json({ answer: response.output_text || 'Non è stata generata una risposta. Riprova con una domanda più specifica.', edition, model: process.env.OPENAI_MODEL || 'gpt-4.1-mini' });
  } catch (error) {
    console.error('OpenAI request failed:', error?.message || error);
    res.status(502).json({ error: 'Non riesco a contattare OpenAI in questo momento. Controlla la configurazione e riprova.' });
  }
});

// Production: serve the built frontend from the same origin.
const distPath = path.resolve(__dirname, '../dist');
app.use(express.static(distPath));
app.get('*', (_req, res, next) => {
  if (_req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(distPath, 'index.html'), err => err && res.status(404).send('Esegui prima npm run build.'));
});
app.listen(PORT, '0.0.0.0', () => console.log(`Grimorio server listening on ${PORT}`));