import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BookOpen, BrainCircuit, Dice5, ScrollText, Users, Bookmark, Settings, Search, Menu, X, Sparkles, Download, Upload, Trash2, Plus, ShieldCheck, MessageCircle, GitCompareArrows, ChevronRight, Copy, RotateCcw } from 'lucide-react';
import './style.css';

const EDITIONS = { '2014': 'D&D 5e · Regole 2014', '2024': 'D&D 5.5e · Regole 2024' };
const initialCharacters = [];
const load = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };

function App() {
  const [edition, setEdition] = useState(() => localStorage.getItem('grimorio-edition') || '2014');
  const [page, setPage] = useState('home');
  const [mobileNav, setMobileNav] = useState(false);
  const [characters, setCharacters] = useState(() => load('grimorio-characters', initialCharacters));
  const [favorites, setFavorites] = useState(() => load('grimorio-favorites', []));
  const [query, setQuery] = useState('');
  const [diceSides, setDiceSides] = useState(20);
  const [diceResult, setDiceResult] = useState(null);
  const [diceHistory, setDiceHistory] = useState([]);
  const [newName, setNewName] = useState('');
  const [newClass, setNewClass] = useState('Guerriero');
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiAnswer, setAiAnswer] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState('');
  const [health, setHealth] = useState({ aiConfigured: false, checked: false });
  const [chatHistory, setChatHistory] = useState([]);
  const [compareLeft, setCompareLeft] = useState('2014');
  const [compareRight, setCompareRight] = useState('2024');

  useEffect(() => { localStorage.setItem('grimorio-edition', edition); }, [edition]);
  useEffect(() => { localStorage.setItem('grimorio-characters', JSON.stringify(characters)); }, [characters]);
  useEffect(() => { localStorage.setItem('grimorio-favorites', JSON.stringify(favorites)); }, [favorites]);
  useEffect(() => { fetch('/api/health').then(r => r.json()).then(d => setHealth({ ...d, checked: true })).catch(() => setHealth({ aiConfigured: false, checked: true })); }, []);

  const nav = [
    { id: 'home', label: 'Sala del Grimorio', icon: BookOpen },
    { id: 'compendium', label: 'Compendio', icon: ScrollText },
    { id: 'assistant', label: 'Oracolo IA', icon: BrainCircuit },
    { id: 'characters', label: 'Personaggi', icon: Users },
    { id: 'dice', label: 'Lancia dadi', icon: Dice5 },
    { id: 'favorites', label: 'Preferiti', icon: Bookmark },
    { id: 'compare', label: 'Confronta edizioni', icon: GitCompareArrows },
    { id: 'settings', label: 'Dati e impostazioni', icon: Settings },
  ];
  const compendium = useMemo(() => [
    { title: 'Prove di caratteristica', type: 'Regole', desc: 'Caratteristiche, prove, CD e tiri salvezza.', editions: ['2014','2024'] },
    { title: 'Combattimento', type: 'Regole', desc: 'Iniziativa, turni, azioni e reazioni.', editions: ['2014','2024'] },
    { title: 'Concentrazione', type: 'Regole', desc: 'Come funziona mantenere un incantesimo.', editions: ['2014','2024'] },
    { title: 'Riposo breve e lungo', type: 'Regole', desc: 'Recupero delle risorse e riposo.', editions: ['2014','2024'] },
    { title: 'Creazione del personaggio', type: 'Personaggi', desc: 'Passaggi per costruire un avventuriero.', editions: ['2014','2024'] },
    { title: 'Incantesimi e componenti', type: 'Magia', desc: 'Lancio, componenti e caratteristiche degli incantesimi.', editions: ['2014','2024'] },
  ].map(x => ({ ...x, edition })), [edition]);
  const filtered = compendium.filter(x => `${x.title} ${x.type} ${x.desc}`.toLowerCase().includes(query.toLowerCase()));

  function addCharacter(e) {
    e.preventDefault();
    if (!newName.trim()) return;
    setCharacters(prev => [...prev, { id: crypto.randomUUID(), name: newName.trim(), className: newClass, level: 1, edition, created: new Date().toISOString() }]);
    setNewName('');
  }
  function roll() {
    const result = Math.floor(Math.random() * diceSides) + 1;
    setDiceResult(result); setDiceHistory(prev => [{ sides: diceSides, result, time: new Date().toLocaleTimeString('it-IT') }, ...prev].slice(0, 12));
  }
  async function askAI(e) {
    e.preventDefault(); if (!aiQuestion.trim()) return;
    setAiLoading(true); setAiError(''); setAiAnswer('');
    try {
      const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: aiQuestion, edition, history: chatHistory }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Richiesta non riuscita.');
      setAiAnswer(data.answer);
      setChatHistory(prev => [...prev, { role: 'user', content: aiQuestion }, { role: 'assistant', content: data.answer }].slice(-16));
      setAiQuestion('');
    } catch (err) { setAiError(err.message || 'Errore di connessione.'); }
    finally { setAiLoading(false); }
  }
  function toggleFavorite(item) {
    setFavorites(prev => prev.some(x => x.title === item.title && x.edition === edition) ? prev.filter(x => !(x.title === item.title && x.edition === edition)) : [...prev, { ...item, edition }]);
  }
  function exportData() {
    const blob = new Blob([JSON.stringify({ version: 1, edition, characters, favorites }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'grimorio-backup.json'; a.click(); URL.revokeObjectURL(url);
  }
  function importData(e) {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { try { const d = JSON.parse(reader.result); if (Array.isArray(d.characters)) setCharacters(d.characters); if (Array.isArray(d.favorites)) setFavorites(d.favorites); if (['2014','2024'].includes(d.edition)) setEdition(d.edition); alert('Backup importato.'); } catch { alert('File di backup non valido.'); } };
    reader.readAsText(file); e.target.value = '';
  }

  const currentPage = nav.find(n => n.id === page)?.label || 'Sala del Grimorio';
  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'open' : ''}`}>
      <div className="brand"><div className="brand-mark"><BookOpen size={25}/></div><div><div className="brand-name">GRIMORIO</div><div className="brand-sub">COMPAGNO D'AVVENTURA</div></div><button className="icon-btn mobile-close" onClick={() => setMobileNav(false)} aria-label="Chiudi menu"><X/></button></div>
      <div className="edition-label">EDIZIONE ATTIVA</div>
      <div className="edition-switch"><button className={edition === '2014' ? 'selected' : ''} onClick={() => setEdition('2014')}>5e · 2014</button><button className={edition === '2024' ? 'selected' : ''} onClick={() => setEdition('2024')}>5.5e · 2024</button></div>
      <div className="nav-caption">IL TUO TAVOLO</div>
      <nav>{nav.map(item => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => { setPage(item.id); setMobileNav(false); }}><Icon size={18}/><span>{item.label}</span>{page === item.id && <ChevronRight size={15} className="nav-chevron"/>}</button>; })}</nav>
      <div className="sidebar-bottom"><div className="seal"><Sparkles size={16}/><span>IL SAPERE È POTERE</span></div><div className="version">GRIMORIO · PROTOTIPO 1.0</div></div>
    </aside>
    {mobileNav && <button className="scrim" onClick={() => setMobileNav(false)} aria-label="Chiudi menu"/>}
    <main className="main-area">
      <header className="topbar"><button className="icon-btn menu-toggle" onClick={() => setMobileNav(true)} aria-label="Apri menu"><Menu/></button><div className="breadcrumbs">GRIMORIO <span>/</span> <b>{currentPage}</b></div><div className="topbar-right"><span className="active-edition"><span className="status-dot"/>{EDITIONS[edition]}</span><div className="avatar">G</div></div></header>
      <div className="content">
        {page === 'home' && <><section className="hero"><div className="hero-copy"><div className="eyebrow"><Sparkles size={14}/> IL TUO ARCHIVIO ARCANO</div><h1>Ogni leggenda<br/>inizia da <em>qui.</em></h1><p>Regole, personaggi e conoscenza per la prossima grande avventura. Il tuo tavolo, raccolto in un unico luogo.</p><button className="primary-btn" onClick={() => setPage('assistant')}><BrainCircuit size={17}/> Interroga l'Oracolo <ChevronRight size={16}/></button></div><div className="hero-art"><div className="rune rune-one">ᚠ</div><div className="rune rune-two">✧</div><div className="orb"><BookOpen size={76} strokeWidth={1}/></div><div className="orbit orbit-a"/><div className="orbit orbit-b"/><div className="hero-caption">ARCANA · MEMORIA · AVVENTURA</div></div></section>
          <div className="section-heading"><div><div className="eyebrow">PANORAMICA</div><h2>Il tuo tavolo, a portata di mano</h2></div><span className="subtle">EDIZIONE {edition}</span></div>
          <div className="stats-grid"><Stat icon={Users} label="Personaggi" value={characters.length} note="Nella tua raccolta" onClick={() => setPage('characters')}/><Stat icon={Bookmark} label="Preferiti" value={favorites.length} note="Voci salvate" onClick={() => setPage('favorites')}/><Stat icon={Dice5} label="Dadi" value="d4–d100" note="Pronti al lancio" onClick={() => setPage('dice')}/><Stat icon={BrainCircuit} label="Oracolo IA" value={health.aiConfigured ? 'Attivo' : 'Da configurare'} note={health.aiConfigured ? 'API collegata' : 'Richiede API key'} onClick={() => setPage('assistant')}/></div>
          <div className="two-col"><section className="panel"><div className="panel-head"><div><div className="eyebrow">CONSULTA</div><h3>Dal compendio</h3></div><button className="text-btn" onClick={() => setPage('compendium')}>Apri archivio <ChevronRight size={15}/></button></div>{compendium.slice(0,4).map((item,i)=><button className="list-row" key={item.title} onClick={() => {setQuery(item.title);setPage('compendium')}}><div className="item-glyph">{['✧','⚔','◈','☾'][i]}</div><div className="list-copy"><b>{item.title}</b><span>{item.desc}</span></div><ChevronRight size={16}/></button>)}</section><section className="panel oracle-panel"><div className="oracle-icon"><BrainCircuit size={24}/></div><div className="eyebrow">IL CONSIGLIERE ARCANO</div><h3>Hai un dubbio sulle regole?</h3><p>Chiedi all'Oracolo. La risposta sarà riferita all'edizione attualmente selezionata.</p><button className="secondary-btn" onClick={() => setPage('assistant')}>Apri l'Oracolo <ChevronRight size={15}/></button><div className="oracle-foot"><ShieldCheck size={14}/> Edizione sempre dichiarata</div></section></div>
        </>}
        {page === 'compendium' && <><PageIntro eyebrow="ARCHIVIO DEL SAPERE" title="Il Compendio" desc={`Esplora le voci disponibili per ${EDITIONS[edition]}. I contenuti sono una struttura iniziale: verifica sempre le regole sui manuali ufficiali.`}/><div className="searchbar"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Cerca regole, magia, combattimento..."/>{query && <button onClick={()=>setQuery('')} aria-label="Cancella ricerca"><X size={16}/></button>}</div><div className="notice"><ShieldCheck size={17}/><span>Edizione attiva: <b>{EDITIONS[edition]}</b>. Il compendio iniziale contiene categorie e promemoria, non una trascrizione completa dei manuali.</span></div><div className="compendium-grid">{filtered.map(item=><article className="comp-card" key={item.title}><div className="comp-card-top"><span className="type-pill">{item.type}</span><button className={`icon-btn favorite-btn ${favorites.some(x=>x.title===item.title&&x.edition===edition)?'is-fav':''}`} onClick={()=>toggleFavorite(item)} aria-label="Salva preferito"><Bookmark size={17}/></button></div><h3>{item.title}</h3><p>{item.desc}</p><div className="comp-card-bottom"><span>{EDITIONS[edition]}</span><span className="tiny-seal">✧</span></div></article>)}</div>{!filtered.length&&<Empty title="Nessuna voce trovata" desc="Prova con un altro termine di ricerca."/>}</>}
        {page === 'assistant' && <><PageIntro eyebrow="INTELLIGENZA ARCANA" title="L'Oracolo" desc="Un assistente conversazionale per ragionare sulle regole e preparare le tue sessioni. Le risposte sono generate dall'IA e vanno verificate sulle fonti ufficiali."/><div className="ai-layout"><section className="panel chat-panel"><div className="chat-header"><div className="oracle-icon"><BrainCircuit size={22}/></div><div><b>Oracolo di Grimorio</b><span><span className={`status-dot ${health.aiConfigured?'':'offline'}`}/>{health.aiConfigured?'API configurata':'API non configurata'}</span></div><span className="chat-edition">{edition}</span></div><div className="chat-body"><div className="assistant-message"><div className="message-avatar"><Sparkles size={17}/></div><div><div className="message-meta">ORACOLO <span>· {EDITIONS[edition]}</span></div><p>Salve, avventuriero. Chiedimi una regola, un'interazione o un consiglio per la tua sessione. Terrò come riferimento l'edizione selezionata.</p><small>Nota: senza una base documentale collegata, non posso garantire citazioni o verifiche puntuali.</small></div></div>{aiAnswer&&<div className="assistant-message"><div className="message-avatar"><Sparkles size={17}/></div><div><div className="message-meta">ORACOLO <span>· {EDITIONS[edition]}</span></div><p className="answer-text">{aiAnswer}</p></div></div>}{aiError&&<div className="error-box">{aiError}</div>}{aiLoading&&<div className="loading-line"><span/><span/><span/> L'Oracolo consulta gli astri...</div>}</div><form className="chat-form" onSubmit={askAI}><textarea value={aiQuestion} onChange={e=>setAiQuestion(e.target.value)} placeholder={`Chiedi qualcosa sulle regole ${edition}...`} rows={3} maxLength={5000}/><div className="chat-form-bottom"><span>Risposte IA · controlla sempre le fonti</span><button className="primary-btn" disabled={aiLoading||!aiQuestion.trim()}>{aiLoading?'Attendi...':'Invia domanda'} <ChevronRight size={15}/></button></div></form></section><aside className="panel tips-panel"><div className="eyebrow">COME INTERROGARLO</div><h3>Domande utili</h3>{['Come funziona la concentrazione in questa edizione?','Spiegami la differenza tra azione e reazione.','Aiutami a preparare un incontro per 4 personaggi.'].map((q,i)=><button className="suggestion" key={q} onClick={()=>setAiQuestion(q)}><MessageCircle size={16}/><span>{q}</span><ChevronRight size={14}/></button>)}<div className="divider-line"/><div className="eyebrow">CONFIGURAZIONE</div><p className="muted-text">La chiave OpenAI va impostata come <code>OPENAI_API_KEY</code> nelle variabili segrete del server. Non inserirla nel testo della chat o nel codice del browser.</p><a className="external-link" href="https://platform.openai.com/" target="_blank" rel="noreferrer">Apri OpenAI Platform <ChevronRight size={14}/></a></aside></div></>}
        {page === 'characters' && <><PageIntro eyebrow="LA TUA COMPAGNIA" title="Personaggi" desc="Crea una raccolta locale dei tuoi avventurieri. Ogni scheda è associata all'edizione attiva al momento della creazione."/><section className="panel create-panel"><div className="panel-head"><div><div className="eyebrow">NUOVO AVVENTURIERO</div><h3>Aggiungi un personaggio</h3></div><div className="item-glyph large">✧</div></div><form className="character-form" onSubmit={addCharacter}><label>Nome del personaggio<input value={newName} onChange={e=>setNewName(e.target.value)} placeholder="Es. Elara Lunargento" maxLength={60} required/></label><label>Classe<select value={newClass} onChange={e=>setNewClass(e.target.value)}>{['Barbaro','Bardo','Chierico','Druido','Guerriero','Ladro','Mago','Monaco','Paladino','Ranger','Stregone','Warlock'].map(c=><option key={c}>{c}</option>)}</select></label><button className="primary-btn"><Plus size={16}/> Crea personaggio</button></form></section>{characters.length ? <div className="character-grid">{characters.map(c=><article className="character-card" key={c.id}><div className="character-emblem"><Users size={25}/></div><div className="type-pill">EDIZIONE {c.edition}</div><h3>{c.name}</h3><p>{c.className} · Livello {c.level}</p><div className="character-footer"><span>Avventuriero</span><button className="icon-btn danger" onClick={()=>setCharacters(prev=>prev.filter(x=>x.id!==c.id))} aria-label="Elimina personaggio"><Trash2 size={16}/></button></div></article>)}</div>:<Empty title="La tua compagnia è ancora vuota" desc="Crea il primo personaggio per iniziare la raccolta."/>}</>}
        {page === 'dice' && <><PageIntro eyebrow="IL CASO DECIDE" title="Lancia dadi" desc="Un lanciadadi rapido per il tavolo. I risultati vengono generati dal dispositivo e non modificano le schede."/><div className="dice-layout"><section className="panel dice-panel"><div className="eyebrow">SCEGLI IL DADO</div><div className="dice-choices">{[4,6,8,10,12,20,100].map(s=><button key={s} className={`die-choice ${diceSides===s?'chosen':''}`} onClick={()=>setDiceSides(s)}><span>d{s}</span></button>)}</div><div className="dice-stage"><div className="die-visual"><Dice5 size={76} strokeWidth={1}/><span>d{diceSides}</span></div><div className="roll-result">{diceResult ?? '—'}</div><span className="muted-text">{diceResult===null?'Pronto al lancio':`Risultato del d${diceSides}`}</span><button className="primary-btn roll-btn" onClick={roll}><Sparkles size={17}/> Lancia d{diceSides}</button></div></section><section className="panel history-panel"><div className="panel-head"><div><div className="eyebrow">ULTIMI LANCI</div><h3>Registro dei dadi</h3></div><button className="icon-btn" onClick={()=>setDiceHistory([])} aria-label="Svuota registro"><RotateCcw size={16}/></button></div>{diceHistory.length?diceHistory.map((r,i)=><div className="roll-row" key={i}><div className="roll-mini">d{r.sides}</div><span>{r.time}</span><b>{r.result}</b></div>):<Empty title="Nessun lancio" desc="Il destino attende il primo tiro."/>}</section></div></>}
        {page === 'favorites' && <><PageIntro eyebrow="SEGNALIBRI ARCANI" title="Preferiti" desc="Le voci salvate sono separate per edizione, così non confondi i riferimenti."/>{favorites.length?<div className="compendium-grid">{favorites.map((item,i)=><article className="comp-card" key={`${item.title}-${item.edition}-${i}`}><div className="comp-card-top"><span className="type-pill">{item.type||'Voce salvata'}</span><button className="icon-btn is-fav" onClick={()=>setFavorites(prev=>prev.filter((_,j)=>j!==i))} aria-label="Rimuovi preferito"><Bookmark size={17}/></button></div><h3>{item.title}</h3><p>{item.desc}</p><div className="comp-card-bottom"><span>{EDITIONS[item.edition]}</span></div></article>)}</div>:<Empty title="Nessun preferito salvato" desc="Apri il compendio e premi il segnalibro su una voce."/>}</>}
        {page === 'compare' && <><PageIntro eyebrow="DUE EDIZIONI, DUE RIFERIMENTI" title="Confronta le edizioni" desc="Usa questo spazio per confrontare le edizioni senza confondere le regole. Le differenze specifiche vanno verificate su fonti ufficiali."/><div className="compare-selectors"><label>Edizione A<select value={compareLeft} onChange={e=>setCompareLeft(e.target.value)}><option value="2014">D&D 5e · 2014</option><option value="2024">D&D 5.5e · 2024</option></select></label><GitCompareArrows size={20}/><label>Edizione B<select value={compareRight} onChange={e=>setCompareRight(e.target.value)}><option value="2014">D&D 5e · 2014</option><option value="2024">D&D 5.5e · 2024</option></select></label></div><div className="compare-grid"><article className="panel compare-card"><div className="edition-ribbon">EDIZIONE A</div><h3>{EDITIONS[compareLeft]}</h3><p>Riferimento separato. Consulta il manuale o il testo SRD corrispondente prima di applicare una regola al tavolo.</p><button className="secondary-btn" onClick={()=>{setEdition(compareLeft);setPage('compendium')}}>Apri compendio A <ChevronRight size={15}/></button></article><article className="panel compare-card"><div className="edition-ribbon">EDIZIONE B</div><h3>{EDITIONS[compareRight]}</h3><p>Riferimento separato. Evita di trasferire automaticamente una regola da un'edizione all'altra.</p><button className="secondary-btn" onClick={()=>{setEdition(compareRight);setPage('compendium')}}>Apri compendio B <ChevronRight size={15}/></button></article></div><div className="notice"><ShieldCheck size={17}/><span>Questo confronto è un contenitore di lavoro, non un elenco esaustivo di differenze ufficiali. Non inventa cambiamenti in assenza di fonti.</span></div></>}
        {page === 'settings' && <><PageIntro eyebrow="CUSTODIA E CONFIGURAZIONE" title="Dati e impostazioni" desc="Gestisci i dati salvati su questo dispositivo, esporta una copia di sicurezza e controlla lo stato dell'assistente."/><div className="settings-grid"><section className="panel settings-card"><div className="settings-icon"><Download size={21}/></div><h3>Backup dei tuoi dati</h3><p>Esporta personaggi, preferiti ed edizione attiva in un file JSON.</p><button className="secondary-btn" onClick={exportData}>Esporta backup <Download size={16}/></button><label className="secondary-btn upload-btn">Importa backup <Upload size={16}/><input type="file" accept="application/json,.json" onChange={importData}/></label></section><section className="panel settings-card"><div className="settings-icon"><BrainCircuit size={21}/></div><h3>Connessione OpenAI</h3><p>Stato: <b>{health.checked?(health.aiConfigured?'API configurata':'API non configurata'):'Verifica in corso...'}</b></p><p>Modello configurato: <code>{health.model || '—'}</code></p><p className="muted-text">La chiave è letta esclusivamente dal server tramite variabile d'ambiente. Non viene salvata nel browser.</p><a className="external-link" href="https://platform.openai.com/api-keys" target="_blank" rel="noreferrer">Gestisci API key <ChevronRight size={14}/></a></section><section className="panel settings-card"><div className="settings-icon"><ShieldCheck size={21}/></div><h3>Privacy e archiviazione</h3><p>Personaggi e preferiti vengono salvati localmente nel browser. Il backup è importante se cancelli i dati del sito o cambi dispositivo.</p><button className="secondary-btn" onClick={()=>{if(confirm('Eliminare tutti i personaggi e i preferiti da questo dispositivo? Esporta prima un backup se vuoi conservarli.')){setCharacters([]);setFavorites([])}}}><Trash2 size={16}/> Cancella dati locali</button></section></div></>}
      </div>
      <footer className="footer"><span>✧ GRIMORIO</span><span>Creato per le tue avventure · Non affiliato a Wizards of the Coast</span></footer>
    </main>
  </div>;
}

function Stat({icon:Icon,label,value,note,onClick}) { return <button className="stat-card" onClick={onClick}><div className="stat-top"><span>{label}</span><Icon size={18}/></div><strong>{value}</strong><small>{note}</small></button>; }
function PageIntro({eyebrow,title,desc}) { return <section className="page-intro"><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{desc}</p></section>; }
function Empty({title,desc}) { return <div className="empty-state"><div className="empty-mark">✧</div><h3>{title}</h3><p>{desc}</p></div>; }

createRoot(document.getElementById('root')).render(<App/>);